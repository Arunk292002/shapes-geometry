def area(a):
    return 2*(1+(2**0.5))*(a**2)
def perimeter(a):
    return 8*a