def area(a):
    return (5/2)*(a**2)*((5+2*(5**0.5)**0.5))
def perimeter(a):
    return 10*a