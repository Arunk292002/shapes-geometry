def area(diagonal_1,diagonal_2):
    return 0.5*diagonal_1*diagonal_2
def perimeter(a,b):
    return 2*(a+b)