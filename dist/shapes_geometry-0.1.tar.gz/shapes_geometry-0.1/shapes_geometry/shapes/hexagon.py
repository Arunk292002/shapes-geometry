def area(a):
    return ((3*(3**0.5))/2)*(a**2)
def perimeter(a):
    return 6*a
