def area(base,height):
    return (height*base)/2
def perimeter(side1,side2,base):
    return side1+base+side2
def find_height(base,Area):
    return 2*(Area/base)
