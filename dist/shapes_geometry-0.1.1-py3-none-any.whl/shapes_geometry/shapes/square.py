def area(side):
    a= side**2
    return a
def perimeter(side):
    p=4*side
    return p
def diagonal(side):
    power=0.5
    d=(2**power)*side
    return d
