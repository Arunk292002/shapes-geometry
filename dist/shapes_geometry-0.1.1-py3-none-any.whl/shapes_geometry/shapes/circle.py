pi=3.141592653589793
def area (radius):
    return pi*radius**2
def diameter(radius):
    return 2*radius
def circumference(radius):
    return 2*pi*radius
