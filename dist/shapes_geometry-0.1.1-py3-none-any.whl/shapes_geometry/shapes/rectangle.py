def area (w,l):
    return w*l
def perimeter(w,l):
    return 2*(l+w)
def diagonal(w,l):
    return (w**2+l**2)**0.5
def find_length(w,P):
    return (P/2)-w
def find_width(l,P):
    return (P/2)-l
