def area(a):
    return (0.25)*((5*(5+2*(5**0.5)))**0.5)*(a**2)
def perimeter(a):
    return 5*a
def find_diagonal(a):
    return ((1+(5**0.5))/2)*a