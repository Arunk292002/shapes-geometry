pi=3.141592653589793
def surface_area(R, r):
    return 4 * (pi**2) * R * r

def volume(R, r):
    return (2 * (pi**2)) * (R * (r**2))