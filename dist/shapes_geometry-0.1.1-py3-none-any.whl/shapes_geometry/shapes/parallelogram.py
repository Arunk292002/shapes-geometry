def area(base,height):
    return base*height
def perimeter(base,side):
    return 2*(side+base)
def find_base(side,Perimeter):
    return (Perimeter/2)-side
def find_side(base,Perimeter):
    return (Perimeter/2)-base
