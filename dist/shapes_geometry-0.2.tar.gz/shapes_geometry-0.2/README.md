# shapes_geometry

`shapes_geometry` is a lightweight Python package for performing geometry calculations for common 2D and 3D shapes. It provides simple functions to compute area, perimeter, volume, surface area, and other geometric properties — perfect for students, educators, and developers building math-related tools.

---

## Features

- **2D Shapes:** Circle, Triangle, Square, Rectangle, Parallelogram, Rhombus, Trapezium, Kite, Semicircle, Regular Polygons (Pentagon, Hexagon, Octagon, Decagon)
- **3D Shapes:** Sphere, Cube, Cuboid, Cone, Cylinder
- Simple API with functional structure (no classes)
- Easy to extend and integrate into other Python projects

---

## 📌 Version History

### v0.2 - Current Version
- Added Torus and Ellipsoid Geometric Calculations.
- Added Regular Polygon Calculations.
- Added `CalculationError` which is raised when calculations cannot be performed.

### v0.1.5
- Added `utils.validate_positive_numbers()` for reusable validation.
- Added Geometric Calculations for Capsule.

### v0.1.4
- Added `utils.validate_positive_numbers()` for reusable validation.
- Applied consistent dimension checks across shapes (circle, cylinder, etc.).
- Improved exception handling with:
  - `ShapesGeometryError`
  - `InvalidDimensionError`
  - `InvalidCoordinateError`

### v0.1.3
- Added support for more 2D and 3D shapes (parallelogram, trapezium, cone, etc.).
- Introduced initial exception handling for invalid dimensions.

### v0.1.2
- Implemented core shapes: Circle, Square, Rectangle, Triangle, Cube, Sphere, Cylinder.
- Added area, perimeter, surface area, and volume functions.

### v0.1.1
- Basic setup with `__init__.py`.
- Organized shapes into modules.
- First working release with Circle and Square.

---

## Installation

```bash
pip install shapes-geometry
```

## Example Usage 

```bash
from shapes_geometry.shapes import circle, square, rectangle

print(circle.area(5))           # Output: 78.53981633974483
print(square.perimeter(4))      # Output: 16
print(rectangle.area(10, 5))    # Output: 50
```
