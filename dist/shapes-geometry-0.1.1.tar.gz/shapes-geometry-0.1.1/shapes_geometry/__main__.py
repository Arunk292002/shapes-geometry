from shapes_geometry.shapes import circle

if __name__ == "__main__":
    c = circle.area(5)
    print(f"Circle with radius 5 has area: {c}")
